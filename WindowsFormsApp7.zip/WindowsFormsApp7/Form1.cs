﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp7
{
    public partial class Form1 :Form
    {
        public Form1 ()
        {
            InitializeComponent();
            this.BackColor = Color.GhostWhite;
        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                double z1 = Convert.ToDouble(textBox1.Text);
                double z2 = Convert.ToDouble(textBox2.Text);
                double i1 = Convert.ToDouble(textBox3.Text);
                double i2 = Convert.ToDouble(textBox4.Text);

                if (radioButton1.Checked)
                {
                    ComplexNumbers complex = new ComplexNumbers(z1,i1);
                    ComplexNumbers complex1 = new ComplexNumbers(z2,i2);

                    ComplexNumbers summa = complex.Slozenie(complex1);

                    if (radioButton8.Checked)
                    {
                        MessageBox.Show(summa.Algebra_Forma());
                    }
                    if (radioButton9.Checked)
                    {
                        MessageBox.Show(summa.Trigonometric_Forma());
                    }
                    if (radioButton10.Checked)
                    {
                        MessageBox.Show(summa.Exponential_Forma());
                    }
                }
                if (radioButton2.Checked)
                {
                    ComplexNumbers complex = new ComplexNumbers(z1, i1);
                    ComplexNumbers complex1 = new ComplexNumbers(z2, i2);

                    ComplexNumbers summa = complex.Vichitanie(complex1);

                    if (radioButton8.Checked)
                    {
                        MessageBox.Show(summa.Algebra_Forma());
                    }
                    if (radioButton9.Checked)
                    {
                        MessageBox.Show(summa.Trigonometric_Forma());
                    }
                    if (radioButton10.Checked)
                    {
                        MessageBox.Show(summa.Exponential_Forma());
                    }
                }
                if (radioButton3.Checked)
                {
                    ComplexNumbers complex = new ComplexNumbers(z1, i1);
                    ComplexNumbers complex1 = new ComplexNumbers(z2, i2);

                    ComplexNumbers summa = complex.Umnozenie(complex1);

                    if (radioButton8.Checked)
                    {
                        MessageBox.Show(summa.Algebra_Forma());
                    }
                    if (radioButton9.Checked)
                    {
                        MessageBox.Show(summa.Trigonometric_Forma());
                    }
                    if (radioButton10.Checked)
                    {
                        MessageBox.Show(summa.Exponential_Forma());
                    }
                }
                if (radioButton4.Checked)
                {
                    ComplexNumbers complex = new ComplexNumbers(z1, i1);
                    ComplexNumbers complex1 = new ComplexNumbers(z2, i2);

                    ComplexNumbers summa = complex.Delenie(complex1);

                    if (radioButton8.Checked)
                    {
                        MessageBox.Show(summa.Algebra_Forma());
                    }
                    if (radioButton9.Checked)
                    {
                        MessageBox.Show(summa.Trigonometric_Forma());
                    }
                    if (radioButton10.Checked)
                    {
                        MessageBox.Show(summa.Exponential_Forma());
                    }
                }
                if (radioButton5.Checked)
                {
                    ComplexNumbers complex = new ComplexNumbers(z1, i1);
                    ComplexNumbers complex1 = new ComplexNumbers(z2, i2);

                    ComplexNumbers summa = complex.Sopryzenie();
                    ComplexNumbers summa2 = complex1.Sopryzenie();

                    if (radioButton8.Checked)
                    {
                        MessageBox.Show(summa.Algebra_Forma(), "Сопряжение Z1 и I1");
                        MessageBox.Show(summa2.Algebra_Forma(), "Сопряжение Z2 и I2");
                    }
                    if (radioButton9.Checked)
                    {
                        MessageBox.Show(summa.Trigonometric_Forma(), "Сопряжение Z1 и I1");
                        MessageBox.Show(summa2.Trigonometric_Forma(), "Сопряжение Z2 и I2");
                    }
                    if (radioButton10.Checked)
                    {
                        MessageBox.Show(summa.Exponential_Forma(), "Сопряжение Z1 и I1");
                        MessageBox.Show(summa2.Exponential_Forma(), "Сопряжение Z2 и I2");
                    }
                }
                if (radioButton6.Checked)
                {
                    ComplexNumbers complex = new ComplexNumbers(z1, i1);
                    ComplexNumbers complex1 = new ComplexNumbers(z2, i2);

                    ComplexNumbers summa = complex.Pow(2);
                    ComplexNumbers summa2 = complex1.Pow(2);

                    if (radioButton8.Checked)
                    {
                        MessageBox.Show(summa.Algebra_Forma(),"1. Возведение в степень 2");
                        MessageBox.Show(summa2.Algebra_Forma(),"2. Возведение в степень 2");
                    }
                    if (radioButton9.Checked)
                    {
                        MessageBox.Show(summa.Trigonometric_Forma(),"1. Возведение в степень 2");
                        MessageBox.Show(summa2.Trigonometric_Forma(),"2. Возведение в степень 2");
                    }
                    if (radioButton10.Checked)
                    {
                        MessageBox.Show(summa.Exponential_Forma(),"1. Возведение в степень 2");
                        MessageBox.Show(summa2.Exponential_Forma(),"2. Возведение в степень 2");
                    }
                }
                if (radioButton7.Checked)
                {
                    ComplexNumbers complex = new ComplexNumbers(z1, i1);
                    ComplexNumbers complex1 = new ComplexNumbers(z2, i2);

                    ComplexNumbers summa = complex.Sqrt();
                    ComplexNumbers summa2 = complex1.Sqrt();

                    if (radioButton8.Checked)
                    {
                        MessageBox.Show(summa.Algebra_Forma(), "Возведение в степень Z1 и I1");
                        MessageBox.Show(summa2.Algebra_Forma(), "Возведение в степень Z2 и I2");
                    }
                    if (radioButton9.Checked)
                    {
                        MessageBox.Show(summa.Trigonometric_Forma(), "Возведение в степень Z1 и I1");
                        MessageBox.Show(summa2.Trigonometric_Forma(), "Возведение в степень Z2 и I2");
                    }
                    if (radioButton10.Checked)
                    {
                        MessageBox.Show(summa.Exponential_Forma(), "Возведение в степень Z1 и I1");
                        MessageBox.Show(summa2.Exponential_Forma(), "Возведение в степень Z2 и I2");
                    }
                }
            }
            catch (Exception ex) 
            {
                MessageBox.Show($"Ошибка: {ex.Message}");
            }
        }

        private void radioButton1_CheckedChanged(object sender, EventArgs e)
        {

        }
    }
}
