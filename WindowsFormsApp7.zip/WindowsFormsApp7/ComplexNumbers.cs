﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WindowsFormsApp7
{
    internal class ComplexNumbers
    {
        public double RealNumbers { get; set; }
        public double ImagineNumbers { get; set; }

        public ComplexNumbers(double real, double imagine)
        {
            RealNumbers = real;
            ImagineNumbers = imagine;
        }


        public ComplexNumbers Slozenie(ComplexNumbers complex)
        {
            return new ComplexNumbers(RealNumbers + complex.RealNumbers, ImagineNumbers + complex.ImagineNumbers);
        }

        public ComplexNumbers Vichitanie(ComplexNumbers complex)
        {
            return new ComplexNumbers(RealNumbers - complex.RealNumbers, ImagineNumbers - complex.ImagineNumbers);
        }

        public ComplexNumbers Umnozenie(ComplexNumbers complex)
        {
            return new ComplexNumbers(RealNumbers * complex.RealNumbers - ImagineNumbers * complex.ImagineNumbers, RealNumbers * complex.ImagineNumbers + ImagineNumbers * complex.RealNumbers);
        }

        public ComplexNumbers Delenie(ComplexNumbers complex)
        {
            double znamenatel = complex.RealNumbers * complex.RealNumbers + complex.ImagineNumbers * complex.ImagineNumbers;
            double new_Real = (RealNumbers * complex.RealNumbers + ImagineNumbers * complex.ImagineNumbers) / znamenatel;
            double new_Imagine = (ImagineNumbers * complex.RealNumbers - RealNumbers * complex.ImagineNumbers) / znamenatel;
            return new ComplexNumbers(new_Real, new_Imagine);
        }

        public ComplexNumbers Sopryzenie()
        {
            return new ComplexNumbers(RealNumbers, -ImagineNumbers);
        }

        public ComplexNumbers Pow(int n)
        {
            if (n == 0)
            {
                return new ComplexNumbers(1, 0);
            }
            ComplexNumbers result = new ComplexNumbers(RealNumbers, ImagineNumbers);
            for (int i = 1; i < n; i++)
            {
                result = result.Umnozenie(this);
            }
            return result;
        }

        public ComplexNumbers Sqrt()
        {
            double module = Math.Sqrt(RealNumbers * RealNumbers + ImagineNumbers * ImagineNumbers);
            double argument = Math.Atan2(ImagineNumbers, RealNumbers);
            double koren_module = Math.Sqrt(module);
            double koren_argumenta = argument / 2;
            double new_Real = koren_module * Math.Cos(koren_argumenta);
            double new_Imagine = koren_module * Math.Sin(koren_argumenta);
            return new ComplexNumbers(new_Real, new_Imagine);
        }

        public string Algebra_Forma()
        {
            return RealNumbers + (ImagineNumbers >= 0 ? "+" : "-") + Math.Abs(ImagineNumbers) + "i";
        }

        public string Trigonometric_Forma()
        {
            double module = Math.Sqrt(RealNumbers * RealNumbers + ImagineNumbers * ImagineNumbers);
            double argument = Math.Atan2(ImagineNumbers, RealNumbers);
            return module + "(cos(" + argument + ") + isin(" + argument + "))";
        }

        public string Exponential_Forma()
        {
            double module = Math.Sqrt(RealNumbers * RealNumbers + ImagineNumbers * ImagineNumbers);
            double argument = Math.Atan2(ImagineNumbers, RealNumbers);
            return module + "e^(i" + argument + ")";
        }
    }

}

